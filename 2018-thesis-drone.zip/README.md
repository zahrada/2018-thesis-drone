Construction of unmanned uerial vehicle for surveying jobs
 Department of Geomatics, FCE CTU in Prague, Czech Republic